#  python must be installed to run
#  This assumes that there is a folder ‘Traces’ in the same directory as the cache_sim. 
#  The ‘Traces’ folder also contains a folder ‘Spec_Benchmark’ that contains all the .din trace files, 
#  to change the trace file directory path, change cache_sim.py line 155 in the main method
#  l1_cache.py, l2_cache.py, and dram.py must be in the same directory as cache_sim.py, these paths can be changed in the imports for cache_sim.py

#if permission is denied to run the script file, execute 'chmod +x run.sh'

python cache_sim.py